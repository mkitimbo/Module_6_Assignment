README
# Fashion MNIST CNN Classifier

This project implements a 6-layer Convolutional Neural Network in **Python** and **R** using **Keras** to classify the Fashion MNIST dataset.

## Contents
- `cnn_fashion_mnist.py`: Python implementation
- `cnn_fashion_mnist.R`: R implementation
- `predictions/`: Folder with predictions on two test images
- `README.md`: Project overview and instructions

## Instructions

### Python
1. Install requirements:
   ```bash
   pip install tensorflow matplotlib
Run the script:

bash
python cnn_fashion_mnist.py
R
Install required libraries:

- **Test Accuracy**: 89.67%
- The CNN was trained on the Fashion MNIST dataset for 5 epochs using a 6-layer architecture (3 convolutional layers and 2 dense layers).
- The model generalizes well, correctly classifying ~9 out of every 10 unseen images.
- While not perfect, this is a strong baseline model and shows that CNNs are effective for image classification tasks.

Future improvements could include adding dropout, increasing the number of filters, or introducing data augmentation for robustness.
________________________________________


R

install.packages("keras")
library(keras)
install_keras()
Run the R script:

R
source("cnn_fashion_mnist.R")
Output
The script will:

Train a CNN on Fashion MNIST

Evaluate accuracy

Predict on two test images and save them in predictions/ folder

Author
Junior Machine Learning Researcher – Microsoft AI

Moses Kitimbo

---