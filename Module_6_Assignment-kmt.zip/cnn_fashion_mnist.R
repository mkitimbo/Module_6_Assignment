library(keras)
library(magrittr)  # or library(dplyr)

# Load dataset
fashion_mnist <- dataset_fashion_mnist()
c(train_images, train_labels) %<-% fashion_mnist$train
c(test_images, test_labels) %<-% fashion_mnist$test

# Normalize
train_images <- train_images / 255
test_images <- test_images / 255

# Reshape
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Define model
model <- keras_model_sequential() %>%
  layer_conv_2d(32, c(3,3), activation = 'relu', input_shape = c(28,28,1)) %>%
  layer_max_pooling_2d(c(2,2)) %>%
  layer_conv_2d(64, c(3,3), activation = 'relu') %>%
  layer_max_pooling_2d(c(2,2)) %>%
  layer_conv_2d(64, c(3,3), activation = 'relu') %>%
  layer_flatten() %>%
  layer_dense(64, activation = 'relu') %>%
  layer_dense(10, activation = 'softmax')

# Compile
model %>% compile(
  loss = 'sparse_categorical_crossentropy',
  optimizer = 'adam',
  metrics = 'accuracy'
)

# Train
model %>% fit(train_images, train_labels, epochs = 5, validation_split = 0.1)

# Evaluate
model %>% evaluate(test_images, test_labels)

# Predict on 2 images
predictions <- model %>% predict(test_images[1:2,,,drop=FALSE])
print(apply(predictions, 1, which.max) - 1) # Subtract 1 for 0-based indexing

