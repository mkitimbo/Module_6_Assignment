README
# Fashion MNIST CNN Classifier

This project implements a 6-layer Convolutional Neural Network in **Python** and **R** using **Keras** to classify the Fashion MNIST dataset.

## Contents
- `cnn_fashion_mnist.py`: Python implementation
- `cnn_fashion_mnist.R`: R implementation
- `predictions/`: Folder with predictions on two test images
- `README.md`: Project overview and instructions

## Instructions

### Python
1. Install requirements:
   ```bash
   pip install tensorflow matplotlib
Run the script:

bash
python cnn_fashion_mnist.py
R
Install required libraries:

- **Test Accuracy**: 89.67%
- The CNN was trained on the Fashion MNIST dataset for 5 epochs using a 6-layer architecture (3 convolutional layers and 2 dense layers).
- The model generalizes well, correctly classifying ~9 out of every 10 unseen images.
- While not perfect, this is a strong baseline model and shows that CNNs are effective for image classification tasks.

Future improvements could include adding dropout, increasing the number of filters, or introducing data augmentation for robustness.
________________________________________


R

install.packages("keras")
library(keras)
install_keras()
Run the R script:

R
source("cnn_fashion_mnist.R")
Output
The script will:

Train a CNN on Fashion MNIST

Evaluate accuracy

Predict on two test images and save them in predictions/ folder

See output
🔢 Model Training Output:
Epoch 1/5
loss: 0.5061 - accuracy: 0.8141 - val_loss: 0.3625 - val_accuracy: 0.8700
Epoch 2/5
loss: 0.3284 - accuracy: 0.8798 - val_loss: 0.3388 - val_accuracy: 0.8733
...
Epoch 5/5
loss: 0.2253 - accuracy: 0.9164 - val_loss: 0.2551 - val_accuracy: 0.9030

✅ What this tells us:
Training Accuracy improves from 81.4% to 91.6%, showing that the model is learning the data well.

Validation Accuracy (on unseen 10% of training data) also increases from 87% to 90.3%, which is a good sign — the model generalizes well.

Loss (a measure of error) consistently decreases — lower is better.

loss vs. val_loss staying close means no overfitting is happening (a good sign).

📊 Model Evaluation on Test Set:
model %>% evaluate(test_images, test_labels)
# Output:
loss: 0.2718
accuracy: 0.9026

our trained model achieves ~90.26% accuracy on completely unseen test data — excellent performance!

The test loss is also low (0.27), aligning well with training/validation — again, no signs of overfitting.

🤖 Model Predictions on 2 Test Images:
sample_images <- test_images[1:2,,, , drop = FALSE]
predictions <- model %>% predict(sample_images)
predicted_classes <- apply(predictions, 1, which.max) - 1
print(predicted_classes)
# Output:
[1] 9 2

our model predicted:

First image is class 9

Second image is class 2

Fashion MNIST Label Index Map:

0 - T-shirt/top
1 - Trouser
2 - Pullover
3 - Dress
4 - Coat
5 - Sandal
6 - Shirt
7 - Sneaker
8 - Bag
9 - Ankle boot
So our predictions are:

Image 1: Ankle boot

Image 2: Pullover

model %>% predict() returns 10 probabilities per image (for each class).

which.max() finds the most probable class.

- 1 corrects for R’s 1-based indexing (Fashion MNIST uses 0-based labels).

📝 Summary:


Author
Junior Machine Learning Researcher – Microsoft AI

Moses Kitimbo

---