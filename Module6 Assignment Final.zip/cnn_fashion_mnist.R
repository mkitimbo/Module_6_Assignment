
# Load required libraries
library(keras)
library(magrittr)
library(reticulate)

# Set the conda environment (adjust the name if different)
use_condaenv("r-tf215", required = TRUE)

# Import TensorFlow and test
tf <- import("tensorflow")
tf$constant("Hello TensorFlow")

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
c(train_images, train_labels) %<-% fashion_mnist$train
c(test_images, test_labels) %<-% fashion_mnist$test

# Normalize pixel values
train_images <- train_images / 255
test_images <- test_images / 255

# Reshape the images to add the channel dimension (batch, 28, 28, 1)
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Define the CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3,3), activation = "relu", input_shape = c(28,28,1)) %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2,2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3,3), activation = "relu") %>%
  layer_flatten() %>%
  layer_dense(units = 64, activation = "relu") %>%
  layer_dense(units = 10, activation = "softmax")

# Compile the model
model %>% compile(
  optimizer = "adam",
  loss = "sparse_categorical_crossentropy",
  metrics = "accuracy"
)

# Train the model
model %>% fit(
  train_images, train_labels,
  epochs = 5,
  validation_split = 0.1
)

# Evaluate the model on test data
model %>% evaluate(test_images, test_labels)

# Predict on first 2 test images
# NOTE: test_images is already in shape (10000, 28, 28, 1)
sample_images <- test_images[1:2,,, , drop = FALSE]
predictions <- model %>% predict(sample_images)

# Show predicted classes (0-based indexing)
predicted_classes <- apply(predictions, 1, which.max) - 1
print(predicted_classes)

